
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { ArrowRight, Heart, Shield, Users, Star, ArrowLeft } from "lucide-react";

interface AntiViolenceCampaignProps {
  onNext: () => void;
}

const AntiViolenceCampaign = ({ onNext }: AntiViolenceCampaignProps) => {
  const [currentSlide, setCurrentSlide] = useState(0);

  const slides = [
    {
      title: "Mamy Wybór",
      subtitle: "Wybieramy Dobro",
      message: "Każdego dnia stajemy przed wyborami. Klasa 3TIB wybiera życzliwość, szacunek i wsparcie.",
      icon: Heart,
      color: "from-pink-500 to-red-500",
      image: "https://images.unsplash.com/photo-1500375592092-40eb2168fd21?w=800&h=600&fit=crop"
    },
    {
      title: "Siła w Jedności",
      subtitle: "Razem Jesteśmy Mocniejsi",
      message: "Prawdziwa siła nie leży w przemocy, ale we współpracy i wzajemnym wsparciu.",
      icon: Users,
      color: "from-blue-500 to-purple-500",
      image: "https://images.unsplash.com/photo-1506744038136-46273834b3fb?w=800&h=600&fit=crop"
    },
    {
      title: "Chronię, Nie Krzywdzę",
      subtitle: "Obrońca, Nie Agresor",
      message: "Używamy naszych talentów i umiejętności, aby chronić innych, nie po to, by krzywdzić.",
      icon: Shield,
      color: "from-green-500 to-teal-500",
      image: "https://images.unsplash.com/photo-1470071459604-3b5ec3a7fe05?w=800&h=600&fit=crop"
    },
    {
      title: "Każdy Ma Znaczenie",
      subtitle: "Szacunek dla Wszystkich",
      message: "W klasie 3TIB każdy głos jest ważny, każda osoba ma wartość i zasługuje na szacunek.",
      icon: Star,
      color: "from-yellow-500 to-orange-500",
      image: "https://images.unsplash.com/photo-1517022812141-23620dba5c23?w=800&h=600&fit=crop"
    }
  ];

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % slides.length);
  };

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev - 1 + slides.length) % slides.length);
  };

  const currentSlideData = slides[currentSlide];

  return (
    <div className="min-h-screen flex flex-col justify-center px-4 py-8">
      <div className="max-w-6xl mx-auto w-full">
        {/* Header */}
        <div className="text-center mb-12 animate-fade-in">
          <Shield className="w-16 h-16 mx-auto mb-6 text-green-400" />
          <h2 className="text-5xl md:text-6xl font-bold bg-gradient-to-r from-green-400 to-blue-400 bg-clip-text text-transparent mb-4">
            Klasa bez Przemocy
          </h2>
          <p className="text-xl text-slate-300 mb-2">
            Kampania społeczna 3TIB
          </p>
          <p className="text-lg text-slate-400">
            Promujemy życzliwość, szacunek i wsparcie
          </p>
        </div>

        {/* Main Campaign Slide */}
        <div className="mb-12">
          <Card className="bg-slate-800/50 border-slate-700 overflow-hidden animate-fade-in">
            <CardContent className="p-0">
              <div className="grid lg:grid-cols-2 min-h-[500px]">
                {/* Image Section */}
                <div 
                  className="relative bg-cover bg-center flex items-center justify-center"
                  style={{ backgroundImage: `url(${currentSlideData.image})` }}
                >
                  <div className="absolute inset-0 bg-black/60"></div>
                  <div className={`relative z-10 w-24 h-24 rounded-full bg-gradient-to-r ${currentSlideData.color} flex items-center justify-center`}>
                    <currentSlideData.icon className="w-12 h-12 text-white" />
                  </div>
                </div>

                {/* Content Section */}
                <div className="p-8 flex flex-col justify-center">
                  <div className="mb-6">
                    <h3 className={`text-4xl font-bold bg-gradient-to-r ${currentSlideData.color} bg-clip-text text-transparent mb-2`}>
                      {currentSlideData.title}
                    </h3>
                    <h4 className="text-xl text-slate-300 mb-4">
                      {currentSlideData.subtitle}
                    </h4>
                    <p className="text-lg text-slate-400 leading-relaxed">
                      {currentSlideData.message}
                    </p>
                  </div>

                  {/* Navigation Controls */}
                  <div className="flex items-center justify-between">
                    <Button
                      onClick={prevSlide}
                      variant="outline"
                      size="sm"
                      className="border-slate-600 text-slate-300 hover:bg-slate-700"
                    >
                      <ArrowLeft className="w-4 h-4" />
                    </Button>

                    <div className="flex space-x-2">
                      {slides.map((_, index) => (
                        <button
                          key={index}
                          onClick={() => setCurrentSlide(index)}
                          className={`w-3 h-3 rounded-full transition-all duration-300 ${
                            index === currentSlide 
                              ? `bg-gradient-to-r ${currentSlideData.color}` 
                              : 'bg-slate-600'
                          }`}
                        />
                      ))}
                    </div>

                    <Button
                      onClick={nextSlide}
                      variant="outline"
                      size="sm"
                      className="border-slate-600 text-slate-300 hover:bg-slate-700"
                    >
                      <ArrowRight className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Values Grid */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          {[
            { title: "Życzliwość", emoji: "😊", description: "Traktujemy innych z dobrocią" },
            { title: "Szacunek", emoji: "🤝", description: "Cenimy różnorodność i odmienność" },
            { title: "Wsparcie", emoji: "💪", description: "Pomagamy sobie nawzajem" },
            { title: "Bezpieczeństwo", emoji: "🛡️", description: "Chronimy siebie i innych" }
          ].map((value, index) => (
            <Card 
              key={index}
              className="bg-slate-800/50 border-slate-700 hover:border-slate-600 transition-all duration-300 transform hover:scale-105 animate-fade-in"
              style={{ animationDelay: `${index * 150}ms` }}
            >
              <CardContent className="p-6 text-center">
                <div className="text-3xl mb-3">{value.emoji}</div>
                <h4 className="text-lg font-semibold text-white mb-2">{value.title}</h4>
                <p className="text-sm text-slate-400">{value.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Call to Action */}
        <div className="text-center animate-fade-in delay-1000">
          <div className="bg-gradient-to-r from-green-500/20 to-blue-500/20 rounded-2xl p-8 mb-6">
            <h3 className="text-2xl font-bold text-white mb-4">
              Dołącz do Naszej Misji
            </h3>
            <p className="text-lg text-slate-300 mb-4 max-w-2xl mx-auto">
              Klasa 3TIB pokazuje, że można być silnym bez przemocy, 
              pewnym siebie bez poniżania innych, i skutecznym poprzez współpracę.
            </p>
            <div className="text-green-400 font-semibold text-lg">
              #KlasaBezPrzemocy #3TIB #WybierzemyDobro
            </div>
          </div>
          
          <Button 
            onClick={onNext}
            className="group bg-gradient-to-r from-green-600 to-blue-600 hover:from-green-700 hover:to-blue-700 text-white px-8 py-4 text-lg rounded-full transition-all duration-300 transform hover:scale-105"
          >
            Kontynuuj
            <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform duration-300" />
          </Button>
        </div>
      </div>
    </div>
  );
};

export default AntiViolenceCampaign;
