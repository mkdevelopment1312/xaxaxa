
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { ArrowRight, Calendar, Gift, Heart, Coffee, Music } from "lucide-react";

interface HolidayCalendarProps {
  onNext: () => void;
}

const HolidayCalendar = ({ onNext }: HolidayCalendarProps) => {
  const [selectedHoliday, setSelectedHoliday] = useState<any>(null);

  const holidays = [
    {
      date: "09.06",
      day: "PON",
      title: "Dzień Najlepszych Przyjaciół",
      icon: Heart,
      description: "Celebrate your closest friendships and the bonds that make life meaningful!",
      color: "from-pink-500 to-red-500",
      activities: ["Napisz list do przyjaciela", "Zrób wspólne zdjęcie", "Podziel się wspomnieniami"]
    },
    {
      date: "10.06",
      day: "WT",
      title: "Dzień Pizzy",
      icon: Gift,
      description: "International day dedicated to everyone's favorite Italian dish!",
      color: "from-orange-500 to-yellow-500",
      activities: ["Zamów pizzę dla klasy", "Naucz się robić ciasto", "Stwórz własną recepturę"]
    },
    {
      date: "11.06",
      day: "ŚR",
      title: "Dzień Kawy",
      icon: Coffee,
      description: "Celebrate the magical bean that keeps the world running!",
      color: "from-amber-600 to-orange-600",
      activities: ["Wypij kawę z przyjacielem", "Naucz się parzenia", "Odwiedź kawiarnię"]
    },
    {
      date: "12.06",
      day: "CZW",
      title: "Dzień Muzyki",
      icon: Music,
      description: "Appreciate the universal language that connects all cultures!",
      color: "from-purple-500 to-indigo-500",
      activities: ["Posłuchaj nowego gatunku", "Zagraj na instrumencie", "Stwórz playlistę"]
    },
    {
      date: "13.06",
      day: "PT",
      title: "Dzień Życzliwości",
      icon: Heart,
      description: "Spread kindness and make the world a little brighter!",
      color: "from-green-500 to-teal-500",
      activities: ["Pomóż komuś", "Uśmiechnij się do obcych", "Zostaw miłą notatkę"]
    },
    {
      date: "14.06",
      day: "SOB",
      title: "Dzień Selfie",
      icon: Gift,
      description: "Capture and share your best moments with the world!",
      color: "from-blue-500 to-purple-500",
      activities: ["Zrób kreatywne selfie", "Użyj nowego filtra", "Podziel się uśmiechem"]
    }
  ];

  return (
    <div className="min-h-screen flex flex-col justify-center px-4 py-8">
      <div className="max-w-6xl mx-auto w-full">
        {/* Header */}
        <div className="text-center mb-12 animate-fade-in">
          <Calendar className="w-16 h-16 mx-auto mb-6 text-purple-400" />
          <h2 className="text-5xl md:text-6xl font-bold bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent mb-4">
            Kalendarz Świąt Nietypowych
          </h2>
          <p className="text-xl text-slate-300 mb-2">
            Odkryj ciekawe okazje do świętowania
          </p>
          <p className="text-lg text-slate-400">
            Najbliższe 2 tygodnie pełne nietypowych świąt
          </p>
        </div>

        {/* Calendar Grid */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 mb-12">
          {holidays.map((holiday, index) => (
            <Card
              key={index}
              className="bg-slate-800/50 border-slate-700 cursor-pointer transition-all duration-300 transform hover:scale-105 hover:shadow-xl group animate-fade-in"
              style={{ animationDelay: `${index * 150}ms` }}
              onClick={() => setSelectedHoliday(holiday)}
            >
              <CardContent className="p-4 text-center">
                <div className="text-2xl font-bold text-purple-400 mb-1">
                  {holiday.date}
                </div>
                <div className="text-xs text-slate-500 mb-3">
                  {holiday.day}
                </div>
                <div className={`w-12 h-12 mx-auto mb-3 rounded-full bg-gradient-to-r ${holiday.color} flex items-center justify-center group-hover:rotate-12 transition-transform duration-300`}>
                  <holiday.icon className="w-6 h-6 text-white" />
                </div>
                <h3 className="text-sm font-semibold text-white mb-2 line-clamp-2">
                  {holiday.title}
                </h3>
                <div className="text-xs text-slate-400">
                  Kliknij aby dowiedzieć się więcej
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Navigation */}
        <div className="text-center animate-fade-in delay-1000">
          <p className="text-lg text-slate-300 mb-6 max-w-2xl mx-auto">
            Każdy dzień to okazja do świętowania! Kliknij na wybrane święto, 
            aby odkryć jego historię i pomysły na celebrację.
          </p>
          
          <Button 
            onClick={onNext}
            className="group bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white px-8 py-4 text-lg rounded-full transition-all duration-300 transform hover:scale-105"
          >
            Kontynuuj
            <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform duration-300" />
          </Button>
        </div>
      </div>

      {/* Holiday Detail Modal */}
      <Dialog open={!!selectedHoliday} onOpenChange={() => setSelectedHoliday(null)}>
        <DialogContent className="bg-slate-800 border-slate-700 text-white max-w-md">
          {selectedHoliday && (
            <>
              <DialogHeader>
                <div className={`w-16 h-16 mx-auto mb-4 rounded-full bg-gradient-to-r ${selectedHoliday.color} flex items-center justify-center`}>
                  <selectedHoliday.icon className="w-8 h-8 text-white" />
                </div>
                <DialogTitle className="text-center text-xl">
                  {selectedHoliday.title}
                </DialogTitle>
                <div className="text-center text-purple-400 font-bold text-lg">
                  {selectedHoliday.date}
                </div>
              </DialogHeader>
              <div className="space-y-4">
                <p className="text-slate-300 text-center">
                  {selectedHoliday.description}
                </p>
                <div>
                  <h4 className="font-semibold mb-2 text-purple-400">Jak świętować:</h4>
                  <ul className="space-y-1">
                    {selectedHoliday.activities.map((activity: string, index: number) => (
                      <li key={index} className="text-sm text-slate-300 flex items-center">
                        <span className="w-2 h-2 bg-purple-400 rounded-full mr-2"></span>
                        {activity}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default HolidayCalendar;
