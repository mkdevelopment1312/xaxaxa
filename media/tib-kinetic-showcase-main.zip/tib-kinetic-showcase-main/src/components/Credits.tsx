
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { ArrowRight, Heart, Code, Star, Users } from "lucide-react";

interface CreditsProps {
  onReset: () => void;
}

const Credits = ({ onReset }: CreditsProps) => {
  const teamMembers = [
    { name: "Cała Klasa 3TIB", role: "Twórcy Treści", contribution: "Pomysły, teksty, inspiracja" },
    { name: "MKDevelopment", role: "Rozwój Techniczny", contribution: "Programowanie, design, animacje" },
    { name: "Lovable.dev", role: "Platforma", contribution: "Narzędzia do tworzenia aplikacji" }
  ];

  const technologies = [
    "React", "TypeScript", "Tailwind CSS", "Shadcn/ui", "Lucide Icons", "Framer Motion"
  ];

  return (
    <div className="min-h-screen flex flex-col justify-center px-4 py-8">
      <div className="max-w-4xl mx-auto w-full text-center">
        {/* Main Title */}
        <div className="mb-16 animate-fade-in">
          <Star className="w-20 h-20 mx-auto mb-8 text-yellow-400 animate-pulse" />
          <h2 className="text-6xl md:text-7xl font-bold bg-gradient-to-r from-yellow-400 via-pink-400 to-purple-400 bg-clip-text text-transparent mb-6">
            Dziękujemy!
          </h2>
          <p className="text-2xl text-slate-300 mb-4">
            Prezentacja klasy 3TIB zakończona
          </p>
          <p className="text-lg text-slate-400">
            Stworzone z pasją i technologią
          </p>
        </div>

        {/* Team Credits */}
        <div className="mb-12 animate-fade-in delay-300">
          <h3 className="text-3xl font-bold text-white mb-8 flex items-center justify-center">
            <Users className="w-8 h-8 mr-3 text-blue-400" />
            Zespół
          </h3>
          <div className="grid md:grid-cols-3 gap-6">
            {teamMembers.map((member, index) => (
              <Card 
                key={index}
                className="bg-slate-800/50 border-slate-700 hover:border-slate-600 transition-all duration-300 transform hover:scale-105"
              >
                <CardContent className="p-6">
                  <h4 className="text-lg font-semibold text-white mb-2">{member.name}</h4>
                  <p className="text-purple-400 font-medium mb-2">{member.role}</p>
                  <p className="text-sm text-slate-400">{member.contribution}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Technologies */}
        <div className="mb-12 animate-fade-in delay-500">
          <h3 className="text-3xl font-bold text-white mb-8 flex items-center justify-center">
            <Code className="w-8 h-8 mr-3 text-green-400" />
            Technologie
          </h3>
          <div className="flex flex-wrap justify-center gap-4">
            {technologies.map((tech, index) => (
              <span 
                key={index}
                className="px-4 py-2 bg-slate-800/50 border border-slate-700 rounded-full text-slate-300 hover:border-slate-600 transition-colors duration-300"
              >
                {tech}
              </span>
            ))}
          </div>
        </div>

        {/* Special Thanks */}
        <div className="mb-12 animate-fade-in delay-700">
          <Card className="bg-gradient-to-r from-purple-900/50 to-pink-900/50 border-purple-700">
            <CardContent className="p-8">
              <Heart className="w-12 h-12 mx-auto mb-4 text-pink-400" />
              <h3 className="text-2xl font-bold text-white mb-4">Specjalne Podziękowania</h3>
              <p className="text-lg text-slate-300 leading-relaxed">
                Dla wszystkich, którzy wspierali klasę 3TIB w realizacji tego projektu. 
                Wasza wiara w nasze możliwości i entuzjazm dla technologii sprawił, 
                że mogliśmy stworzyć coś wyjątkowego.
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Final Message */}
        <div className="mb-12 animate-fade-in delay-1000">
          <h3 className="text-3xl font-bold bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent mb-6">
            Klasa 3TIB - Razem ku Przyszłości
          </h3>
          <p className="text-xl text-slate-300 mb-8 max-w-2xl mx-auto leading-relaxed">
            Ta prezentacja to tylko początek naszej podróży. Jako klasa 3TIB będziemy 
            kontynuować naukę, wzrost i budowanie lepszego świata przez technologię i współpracę.
          </p>
          
          <div className="space-y-4">
            <Button 
              onClick={onReset}
              className="group bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white px-8 py-4 text-lg rounded-full transition-all duration-300 transform hover:scale-105 mr-4"
            >
              Zobacz Ponownie
              <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform duration-300" />
            </Button>
          </div>
        </div>

        {/* Footer */}
        <div className="text-center text-slate-500 animate-fade-in delay-1200">
          <p className="mb-2">© 2024 Klasa 3TIB</p>
          <p className="text-sm">
            Stworzone z ❤️ przez <span className="text-purple-400 font-semibold">MKDevelopment</span>
          </p>
          <p className="text-xs mt-2">
            Powered by Lovable.dev
          </p>
        </div>
      </div>
    </div>
  );
};

export default Credits;
