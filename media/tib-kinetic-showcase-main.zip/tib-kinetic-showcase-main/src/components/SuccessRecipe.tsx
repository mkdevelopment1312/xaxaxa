
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { ArrowRight, ChefHat, Plus } from "lucide-react";

interface SuccessRecipeProps {
  onNext: () => void;
}

const SuccessRecipe = ({ onNext }: SuccessRecipeProps) => {
  const [addedIngredients, setAddedIngredients] = useState<string[]>([]);
  const [isCooked, setIsCooked] = useState(false);

  const ingredients = [
    {
      name: "Szczypta Szacunku",
      amount: "100g",
      description: "Podstawa każdej udanej współpracy",
      color: "from-blue-500 to-indigo-500"
    },
    {
      name: "Garść Wsparcia",
      amount: "200ml",
      description: "Niezbędny składnik w trudnych chwilach",
      color: "from-green-500 to-emerald-500"
    },
    {
      name: "Łyżka Ambicji",
      amount: "3 łyżki",
      description: "Napędza nas do osiągania celów",
      color: "from-orange-500 to-red-500"
    },
    {
      name: "Szklanka Kreatywności",
      amount: "250ml",
      description: "Dodaje smaku i oryginalności",
      color: "from-purple-500 to-pink-500"
    },
    {
      name: "Odrobina Humoru",
      amount: "do smaku",
      description: "Sprawia, że wszystko jest lepsze",
      color: "from-yellow-500 to-orange-500"
    },
    {
      name: "Dużo Cierpliwości",
      amount: "bez limitu",
      description: "Pozwala dojrzeć najlepszym pomysłom",
      color: "from-teal-500 to-cyan-500"
    }
  ];

  const addIngredient = (ingredient: string) => {
    if (!addedIngredients.includes(ingredient)) {
      setAddedIngredients([...addedIngredients, ingredient]);
    }
  };

  const cookSuccess = () => {
    if (addedIngredients.length === ingredients.length) {
      setIsCooked(true);
    }
  };

  return (
    <div className="min-h-screen flex flex-col justify-center px-4 py-8">
      <div className="max-w-6xl mx-auto w-full">
        {/* Header */}
        <div className="text-center mb-12 animate-fade-in">
          <ChefHat className="w-16 h-16 mx-auto mb-6 text-orange-400" />
          <h2 className="text-5xl md:text-6xl font-bold bg-gradient-to-r from-orange-400 to-red-400 bg-clip-text text-transparent mb-4">
            Przepis na Sukces
          </h2>
          <p className="text-xl text-slate-300 mb-2">
            Kulinarna metafora wartości klasy 3TIB
          </p>
          <p className="text-lg text-slate-400">
            Kliknij składniki aby dodać je do przepisu
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-8 mb-12">
          {/* Ingredients */}
          <div>
            <h3 className="text-2xl font-bold text-white mb-6 animate-fade-in">
              Składniki:
            </h3>
            <div className="space-y-4">
              {ingredients.map((ingredient, index) => (
                <Card
                  key={index}
                  className={`cursor-pointer transition-all duration-300 transform hover:scale-105 ${
                    addedIngredients.includes(ingredient.name)
                      ? 'bg-green-800/50 border-green-500'
                      : 'bg-slate-800/50 border-slate-700 hover:border-slate-600'
                  } animate-fade-in`}
                  style={{ animationDelay: `${index * 100}ms` }}
                  onClick={() => addIngredient(ingredient.name)}
                >
                  <CardContent className="p-4">
                    <div className="flex items-center space-x-4">
                      <div className={`w-12 h-12 rounded-full bg-gradient-to-r ${ingredient.color} flex items-center justify-center flex-shrink-0`}>
                        {addedIngredients.includes(ingredient.name) ? (
                          <Plus className="w-6 h-6 text-white rotate-45" />
                        ) : (
                          <Plus className="w-6 h-6 text-white" />
                        )}
                      </div>
                      <div className="flex-1">
                        <div className="flex justify-between items-start mb-1">
                          <h4 className="font-semibold text-white">{ingredient.name}</h4>
                          <span className="text-sm text-slate-400">{ingredient.amount}</span>
                        </div>
                        <p className="text-sm text-slate-400">{ingredient.description}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          {/* Cooking Pot */}
          <div className="animate-fade-in delay-500">
            <h3 className="text-2xl font-bold text-white mb-6">
              Garnuszek Sukcesu:
            </h3>
            <Card className="bg-slate-800/50 border-slate-700 h-96">
              <CardContent className="p-8 h-full flex flex-col">
                <div className="flex-1 relative">
                  {/* Pot illustration */}
                  <div className="w-48 h-48 mx-auto relative">
                    <div className="w-full h-40 bg-gradient-to-b from-slate-600 to-slate-800 rounded-b-full border-4 border-slate-500"></div>
                    <div className="absolute top-0 left-4 right-4 h-8 bg-slate-500 rounded-t-lg"></div>
                    
                    {/* Steam animation when cooking */}
                    {isCooked && (
                      <div className="absolute -top-8 left-1/2 transform -translate-x-1/2">
                        <div className="w-2 h-8 bg-white/30 rounded-full animate-pulse"></div>
                        <div className="w-1 h-6 bg-white/20 rounded-full ml-4 animate-pulse delay-300"></div>
                        <div className="w-1 h-4 bg-white/20 rounded-full ml-2 animate-pulse delay-500"></div>
                      </div>
                    )}
                    
                    {/* Added ingredients visualization */}
                    <div className="absolute inset-4 top-8 rounded-b-full overflow-hidden">
                      {addedIngredients.map((ingredient, index) => (
                        <div
                          key={index}
                          className={`absolute bottom-0 left-0 right-0 bg-gradient-to-t ${
                            ingredients.find(i => i.name === ingredient)?.color || 'from-gray-500 to-gray-600'
                          } opacity-60`}
                          style={{ 
                            height: `${(index + 1) * (100 / ingredients.length)}%`,
                            borderRadius: '0 0 50% 50%'
                          }}
                        />
                      ))}
                    </div>
                  </div>
                </div>

                <div className="text-center">
                  <p className="text-sm text-slate-400 mb-4">
                    Dodano: {addedIngredients.length}/{ingredients.length} składników
                  </p>
                  
                  {addedIngredients.length === ingredients.length && !isCooked && (
                    <Button
                      onClick={cookSuccess}
                      className="bg-gradient-to-r from-orange-600 to-red-600 hover:from-orange-700 hover:to-red-700 text-white px-6 py-2 rounded-full"
                    >
                      Ugotuj Sukces! 🔥
                    </Button>
                  )}
                  
                  {isCooked && (
                    <div className="animate-fade-in">
                      <div className="text-2xl mb-2">🏆</div>
                      <p className="text-green-400 font-semibold">Sukces gotowy!</p>
                      <p className="text-sm text-slate-400">Klasa 3TIB - przepis na zwycięstwo</p>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Navigation */}
        <div className="text-center animate-fade-in delay-1000">
          <p className="text-lg text-slate-300 mb-6 max-w-2xl mx-auto">
            Sukces to nie przypadek - to starannie przygotowany przepis z najlepszych składników. 
            Klasa 3TIB wie, jak go przygotować!
          </p>
          
          <Button 
            onClick={onNext}
            className="group bg-gradient-to-r from-orange-600 to-red-600 hover:from-orange-700 hover:to-red-700 text-white px-8 py-4 text-lg rounded-full transition-all duration-300 transform hover:scale-105"
          >
            Kontynuuj
            <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform duration-300" />
          </Button>
        </div>
      </div>
    </div>
  );
};

export default SuccessRecipe;
