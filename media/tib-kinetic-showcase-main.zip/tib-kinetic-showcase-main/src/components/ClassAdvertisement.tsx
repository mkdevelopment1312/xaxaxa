
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { ArrowRight, Users, Code, Heart, Zap } from "lucide-react";

interface ClassAdvertisementProps {
  onNext: () => void;
}

const ClassAdvertisement = ({ onNext }: ClassAdvertisementProps) => {
  const [selectedStudent, setSelectedStudent] = useState<number | null>(null);

  const features = [
    {
      icon: Code,
      title: "Technologia",
      description: "Programowanie to nasza pasja",
      color: "from-blue-500 to-cyan-500"
    },
    {
      icon: Users,
      title: "Zespół",
      description: "Razem jesteśmy silniejsi",
      color: "from-purple-500 to-pink-500"
    },
    {
      icon: Heart,
      title: "Przyjaźń",
      description: "Wspieramy się nawzajem",
      color: "from-red-500 to-orange-500"
    },
    {
      icon: Zap,
      title: "Energia",
      description: "Pełni entuzjazmu i pomysłów",
      color: "from-yellow-500 to-green-500"
    }
  ];

  const students = [
    { name: "Anna K.", role: "Frontend Developer", hobby: "UI/UX Design" },
    { name: "Michał P.", role: "Backend Developer", hobby: "Gaming" },
    { name: "Kasia W.", role: "Full Stack", hobby: "Fotografia" },
    { name: "Tomek S.", role: "DevOps", hobby: "Muzyka" },
    { name: "Ola M.", role: "Designer", hobby: "Podróże" },
    { name: "Paweł R.", role: "Tester", hobby: "Sport" }
  ];

  return (
    <div className="min-h-screen flex flex-col justify-center px-4 py-8">
      <div className="max-w-6xl mx-auto w-full">
        {/* Header */}
        <div className="text-center mb-12 animate-fade-in">
          <h2 className="text-5xl md:text-6xl font-bold bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent mb-4">
            Klasa 3TIB
          </h2>
          <p className="text-xl text-slate-300 mb-2">
            Nasz styl to <span className="text-green-400 font-semibold">Benzol</span>
          </p>
          <p className="text-lg text-slate-400">
            Nasza siła to przyjaźń i technologia
          </p>
        </div>

        {/* Features Grid */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          {features.map((feature, index) => (
            <Card 
              key={index}
              className="bg-slate-800/50 border-slate-700 hover:border-slate-600 transition-all duration-300 transform hover:scale-105 hover:shadow-xl cursor-pointer group animate-fade-in"
              style={{ animationDelay: `${index * 200}ms` }}
            >
              <CardContent className="p-6 text-center">
                <div className={`w-16 h-16 mx-auto mb-4 rounded-full bg-gradient-to-r ${feature.color} flex items-center justify-center group-hover:rotate-12 transition-transform duration-300`}>
                  <feature.icon className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-lg font-semibold text-white mb-2">{feature.title}</h3>
                <p className="text-sm text-slate-400">{feature.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Students Section */}
        <div className="mb-12">
          <h3 className="text-3xl font-bold text-center text-white mb-8 animate-fade-in">
            Poznaj Nasz Zespół
          </h3>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
            {students.map((student, index) => (
              <Card
                key={index}
                className={`bg-slate-800/50 border-slate-700 cursor-pointer transition-all duration-300 transform hover:scale-105 ${
                  selectedStudent === index ? 'border-purple-500 bg-purple-900/20' : 'hover:border-slate-600'
                } animate-fade-in`}
                style={{ animationDelay: `${index * 100}ms` }}
                onClick={() => setSelectedStudent(selectedStudent === index ? null : index)}
              >
                <CardContent className="p-4 text-center">
                  <div className="w-12 h-12 mx-auto mb-3 rounded-full bg-gradient-to-r from-purple-500 to-pink-500 flex items-center justify-center">
                    <span className="text-white font-bold text-lg">
                      {student.name.charAt(0)}
                    </span>
                  </div>
                  <h4 className="text-sm font-semibold text-white mb-1">{student.name}</h4>
                  <p className="text-xs text-slate-400">{student.role}</p>
                  {selectedStudent === index && (
                    <div className="mt-2 p-2 bg-slate-700/50 rounded animate-fade-in">
                      <p className="text-xs text-purple-300">Hobby: {student.hobby}</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Call to Action */}
        <div className="text-center animate-fade-in delay-1000">
          <p className="text-lg text-slate-300 mb-6 max-w-2xl mx-auto">
            Jesteśmy grupą pasjonatów technologii, którzy wierzą w siłę współpracy 
            i innowacyjnego myślenia. Dołącz do nas w tej cyfrowej podróży!
          </p>
          
          <Button 
            onClick={onNext}
            className="group bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white px-8 py-4 text-lg rounded-full transition-all duration-300 transform hover:scale-105"
          >
            Kontynuuj
            <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform duration-300" />
          </Button>
        </div>
      </div>
    </div>
  );
};

export default ClassAdvertisement;
