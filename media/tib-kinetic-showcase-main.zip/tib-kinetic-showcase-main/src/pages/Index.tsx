
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { ArrowRight } from "lucide-react";
import StartScreen from "@/components/StartScreen";
import ClassAdvertisement from "@/components/ClassAdvertisement";
import HolidayCalendar from "@/components/HolidayCalendar";
import SuccessRecipe from "@/components/SuccessRecipe";
import AntiViolenceCampaign from "@/components/AntiViolenceCampaign";
import Credits from "@/components/Credits";

const Index = () => {
  const [currentSection, setCurrentSection] = useState(0);

  const sections = [
    { component: StartScreen, title: "Start" },
    { component: ClassAdvertisement, title: "Reklama Klasy" },
    { component: HolidayCalendar, title: "Kalendarz Świąt Nietypowych" },
    { component: SuccessRecipe, title: "Przepis na Sukces" },
    { component: AntiViolenceCampaign, title: "Klasa bez Przemocy" },
    { component: Credits, title: "Credits" }
  ];

  const nextSection = () => {
    if (currentSection < sections.length - 1) {
      setCurrentSection(currentSection + 1);
    }
  };

  const resetToStart = () => {
    setCurrentSection(0);
  };

  const CurrentComponent = sections[currentSection].component;

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 overflow-hidden">
      <div className="relative h-screen">
        <div 
          className="transition-all duration-1000 ease-in-out transform"
          key={currentSection}
        >
          <CurrentComponent 
            onNext={nextSection} 
            onReset={resetToStart}
            isLastSection={currentSection === sections.length - 1}
          />
        </div>
      </div>
    </div>
  );
};

export default Index;
